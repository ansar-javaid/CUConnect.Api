import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native'
import React from 'react'
import share from '../assets/share.png';
import like from '../assets/like.png';
import view from '../assets/view.png';
export default function Post(props) {
    return (
        <View>
            <View style={styles.headingContainer}>
                <Text style={styles.departmentName}>{props.departmentName}</Text>
                <Text style={styles.time}>{props.time} hours ago</Text>
            </View>
            <View style={styles.imageContainer}>
                <Image
                    source={require('../assets/bg.jpg')}
                    style={styles.image}
                ></Image>
            </View>
            <View style={styles.statesContainer}>
                <TouchableOpacity><Text>{props.views} <Image source={view} /></Text></TouchableOpacity>
                <TouchableOpacity><Text>{props.shares} <Image source={share} /></Text></TouchableOpacity>
                <TouchableOpacity><Text>{props.likes} <Image source={like} /></Text></TouchableOpacity>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    headingContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingVertical: 15,
        backgroundColor: '#fff',
        paddingHorizontal: 5
    },
    departmentName: {
        fontSize: 16,
        fontWeight: '700'
    },
    time: {
        fontWeight: '500'
    },
    imageContainer: {
        maxHeight: 300
    },
    image: {
        width: '100%',
        height: '100%'
    },
    statesContainer: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        alignItems: 'center',
        paddingVertical: 15,
        backgroundColor: '#fff'
    }
})