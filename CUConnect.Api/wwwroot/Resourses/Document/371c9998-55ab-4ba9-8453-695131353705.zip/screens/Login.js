import { View, Text, StyleSheet, Image, TextInput, TouchableOpacity, ScrollView } from 'react-native'
import React from 'react'
import comsatslogo from '../assets/comsatslogo.png';
import { LinearGradient } from 'expo-linear-gradient'
import { useState } from 'react/cjs/react.development';

export default function Login({navigation}) {
    
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    function validate() {
        var validationText = ''
        if (username.length == 0) {
            validationText = 'Username is Required\n'
        } if (password.length === 0) {
            validationText += 'Password is Required\n'
        } 
        if (validationText.length > 0) {
            alert(validationText)   
        } else {
            navigation.navigate('Home')
        }


    }
    return (
        <View style={{backgroundColor: '#fff'}}>
            <Image
                style={styles.topImage}
                source={require('../assets/bg.png')}></Image>
                <Image
                style={styles.logoImage}
                source={require('../assets/comsatslogo.png')}></Image>
            <View style={styles.signupContent}>
                <ScrollView>
                <Text style={styles.mainHeading}>Login</Text>
                <TextInput style={styles.input} placeholder='Username' onChangeText={(text)=>setUsername(text)}/>
                <TextInput style={styles.input} placeholder='Password' onChangeText={(text)=>setPassword(text)}/>
                <Text style={styles.password}>FORGOT PASSWORD</Text>

                <View style={styles.buttonContainer}>
                    <TouchableOpacity
                    onPress={()=>{validate()}}
                    >
                        <LinearGradient
                            start={{ x: 1, y: 0 }} end={{ x: 0, y: 0 }}
                            colors={['#4B277E', '#105DA5']} style={styles.buttonInner}>
                            <Text style={styles.buttonText}>Login</Text>
                        </LinearGradient>
                    </TouchableOpacity>
                    <TouchableOpacity
                    onPress={()=>{navigation.navigate('Signup')}}
                    >
                        <LinearGradient
                            start={{ x: 1, y: 0 }} end={{ x: 0, y: 0 }}
                            colors={['#8E8E8E', '#CDCDCD']} style={styles.buttonInner}>
                            <Text style={styles.buttonTextAccount}>Create Account</Text>
                        </LinearGradient>
                    </TouchableOpacity>
                </View>
                </ScrollView>
            </View>
        </View>
    )
}
const styles = StyleSheet.create({
    topImage: {
        position: 'absolute',
        top: 0
    },
    logoImage: {
        position: 'absolute',
        top: 80,
        left: '22%',
        width: 160,
        height: 160,
        left: '50%',
        marginLeft: -80
    },
    signupContent: {
        height: '100%',
        width: '100%',
        backgroundColor: '#fff',
        marginTop: 'auto',
        borderTopLeftRadius: 20,
        borderTopRightRadius: 20,
        marginBottom: -250
    },
    mainHeading: {
        fontSize: 27,
        fontWeight: 'bold',
        textAlign: 'center',
        marginVertical: 15
    },
    input: {
        backgroundColor: '#F3F5F7',
        padding: 15,
        borderRadius: 50,
        marginHorizontal: 20,
        marginVertical: 7
    },
    buttonContainer: {
        alignItems: 'center',
        borderRadius: 30,
        marginTop: 40
    },
    buttonInner: {
        borderRadius: 30,
        marginBottom: 15
    },
    buttonText: {
        paddingHorizontal: 160,
        paddingVertical: 19,
        color: '#fff'
    },
    buttonTextAccount: {
        paddingHorizontal: 130,
        paddingVertical: 19,
        color: '#fff'
    },
    password: {
        color: '#5252C7',
        textAlign: 'center',
        alignItems:'center',
        marginTop:30
    }
})