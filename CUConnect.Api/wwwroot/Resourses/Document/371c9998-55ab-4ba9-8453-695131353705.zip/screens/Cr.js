import { View, Text, StyleSheet, Image, TextInput, TouchableOpacity } from 'react-native'
import React from 'react'
import { LinearGradient } from 'expo-linear-gradient'

export default function Cr({navigation}) {
    return (
            <View>
            <Image
                style={styles.topImage}
                source={require('../assets/bg.png')}></Image>
            <View style={styles.signupContent}>
                <Text style={styles.mainHeading}>Create CR Profile</Text>
                <TextInput style={styles.input} placeholder='CR Name' />
                <TextInput style={styles.input} placeholder='Email (@CUIATD.EDU.PK)' />
                <TextInput style={styles.input} placeholder='Department' />
                <TextInput style={styles.input} placeholder='Section Name' />
                <TextInput style={styles.input} placeholder='Semester' />
                <TextInput style={styles.input} placeholder='Select Profile Picture' />

                <View style={styles.buttonContainer}>
                    <TouchableOpacity
                    onPress={()=>{navigation.navigate('Home')}}
                    >
                        <LinearGradient
                            start={{ x: 1, y: 0 }} end={{ x: 0, y: 0 }}
                            colors={['#4B277E', '#105DA5']} style={styles.buttonInner}>
                            <Text style={styles.buttonText}>Create</Text>
                        </LinearGradient>
                    </TouchableOpacity>
                </View>
            </View>

</View>
    )
}

const styles = StyleSheet.create({
    topImage: {
        position: 'absolute',
        top: 0
    },
    signupContent: {
        height: '100%',
        width: '100%',
        backgroundColor: '#fff',
        marginTop: 'auto',
        borderTopLeftRadius: 20,
        borderTopRightRadius: 20,
        marginBottom: -70
    },
    mainHeading: {
        fontSize: 27,
        fontWeight: 'bold',
        textAlign: 'center',
        marginVertical: 15
    },
    input: {
        backgroundColor: '#F3F5F7',
        padding: 15,
        borderRadius: 50,
        marginHorizontal: 20,
        marginVertical: 7
    },
    buttonContainer: {
        alignItems: 'center',
        borderRadius: 30,
        marginTop: '30%'
    },
    buttonInner: {
        borderRadius: 30
    },
    buttonText: {
        paddingHorizontal: 130,
        paddingVertical: 19,
        color: '#fff'
    }
})