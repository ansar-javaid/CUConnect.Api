import { View, Text, StyleSheet, Image, TextInput, TouchableOpacity, ScrollView } from 'react-native'
import React, { useState } from 'react'
import { LinearGradient } from 'expo-linear-gradient'
import Pressable from 'react-native/Libraries/Components/Pressable/Pressable'

export default function Signup({navigation}) {
    const [gender, setGender] = useState('male');
    const [selectValues] = useState([
        {value: 'male', url: require('../assets/male.jpeg')},
        {value: 'female', url: require('../assets/female.jpeg')}
    ])
    const [firstName,setFirstName] = useState('')
    const [lastName,setLastName] = useState('')
    const [email,setEmail] = useState('')
    const [password,setPassword] = useState('')
    const [confirmPassword,setConfirmPassword] = useState('')

    function validate() {
        var validationText = ''
        if (firstName.length == 0) {
            validationText = 'First Name is Required\n'
        } if (lastName.length === 0) {
            validationText += 'Last Name is Required\n'
        } if (email.length === 0) {
            validationText += 'Email is Required\n'
        } if (password.length === 0) {
            validationText += 'Password is Required\n'
        } if (confirmPassword.length === 0) {
            validationText += 'Confirm Password is Required\n'
        } if (password !== confirmPassword) {
            validationText += 'Passwords donot match'
        }
        if (validationText.length > 0) {
            alert(validationText)   
        } else {
            navigation.navigate('Home')
        }


    }
    
    return (
            <View>
            <Image
                style={styles.topImage}
                source={require('../assets/bg.png')}></Image>
            <View style={styles.signupContent}>
                <ScrollView>
                <Text style={styles.mainHeading}>Create Account</Text>
                <TextInput style={styles.input} placeholder='First Name' onChangeText={(text)=>setFirstName(text)}/>
                <TextInput style={styles.input} placeholder='Last Name' onChangeText={(text)=>setLastName(text)}/>
                <View style={styles.genderContainer}>
                {selectValues.map(item => {
                    return(
                        <TouchableOpacity onPress={()=> setGender(item.value)}>
                            <Image source={item.url} style={styles.genderImage} resizeMode='cover'></Image>
                        </TouchableOpacity>
                    )
                })}
                </View>
               <Text style={{textAlign:'center', color:'#105da5', fontWeight:'bold'}}>{gender === 'male' ? 'Male': 'Female'}</Text>
                <TextInput style={styles.input} placeholder='Email (@CUIATD.EDU.PK)' onChangeText={(text)=>setEmail(text)}/>
                <TextInput style={styles.input} placeholder='Password' secureTextEntry={true} onChangeText={(text)=>setPassword(text)}/>
                <TextInput style={styles.input} placeholder='Confirm Password' secureTextEntry={true} onChangeText={(text)=>setConfirmPassword(text)}/>

                <View style={styles.buttonContainer}>
                    <TouchableOpacity
                    onPress={()=>validate()}
                    >
                        <LinearGradient
                            start={{ x: 1, y: 0 }} end={{ x: 0, y: 0 }}
                            colors={['#4B277E', '#105DA5']} style={styles.buttonInner}>
                            <Text style={styles.buttonText}>Create Account</Text>
                        </LinearGradient>
                    </TouchableOpacity>
                </View>
                </ScrollView>
            </View>

</View>
    )
}

const styles = StyleSheet.create({
    topImage: {
        position: 'absolute',
        top: 0
    },
    genderImage:{
        width: 70,
        height: 70
    },
    genderContainer: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        marginVertical: 15
    },
    signupContent: {
        height: '100%',
        width: '100%',
        backgroundColor: '#fff',
        marginTop: 'auto',
        borderTopLeftRadius: 20,
        borderTopRightRadius: 20,
        marginBottom: -70
    },
    mainHeading: {
        fontSize: 27,
        fontWeight: 'bold',
        textAlign: 'center',
        marginVertical: 15
    },
    input: {
        backgroundColor: '#F3F5F7',
        padding: 15,
        borderRadius: 50,
        marginHorizontal: 20,
        marginVertical: 7
    },
    buttonContainer: {
        alignItems: 'center',
        borderRadius: 30,
        marginTop: '10%'
    },
    buttonInner: {
        borderRadius: 30
    },
    buttonText: {
        paddingHorizontal: 130,
        paddingVertical: 19,
        color: '#fff'
    }
})