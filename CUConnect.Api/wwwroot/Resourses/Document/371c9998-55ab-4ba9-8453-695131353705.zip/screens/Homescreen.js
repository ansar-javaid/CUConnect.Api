import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView } from 'react-native'
import React from 'react'
import { LinearGradient } from 'expo-linear-gradient'
import Post from '../components/Post'
import { useState } from 'react'
import { FontAwesome } from '@expo/vector-icons';
import KeyboardAvoidingView from 'react-native/Libraries/Components/Keyboard/KeyboardAvoidingView'

export default function Homescreen() {

    const [posts]= useState([
        {
            departmentName: 'CS Department',
            time: 2,
            likes: 20,
            views: 50,
            shares: 10
        },
        {
            departmentName: 'CS Department',
            time: 2,
            likes: 20,
            views: 50,
            shares: 10
        }
    ])


    return (
        <KeyboardAvoidingView style={styles.container}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        
        enabled={false}
        >
            <View style={styles.searchContainer}>
                <TextInput
                    style={styles.search}
                    placeholder='search'
                />
                <FontAwesome name={'search'} size={22} style={styles.searchIcon}/>
            </View>
            <View style={styles.welcomeContainer}>
                <Text style={styles.welcomeText}>Welcome CS Department</Text>
                <TextInput
                    style={styles.welcomeInput}
                    placeholder='Type Something'
                />
                <TouchableOpacity>
                    <LinearGradient
                        start={{ x: 1, y: 0 }} end={{ x: 0, y: 0 }}
                        colors={['#4B277E', '#105DA5']} style={styles.buttonInner}>
                        <Text style={styles.buttonText}>Post</Text>
                    </LinearGradient>
                </TouchableOpacity>
            </View>
            <View style={styles.postsContainer}>
                <Text style={styles.postText}>Recent Posts</Text>
                <ScrollView>
                {posts.map(post => {
                    return(
                        <View
                        style={styles.post}>
                        <Post
                        departmentName={post.departmentName}
                        time={post.time}
                        likes={post.likes}
                        views={post.views}
                        shares={post.shares}
                        />
                        </View>
                    )
                })}
                </ScrollView>
            </View>
        </KeyboardAvoidingView>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingTop: 20,
        backgroundColor: '#bfe0ff',
        paddingHorizontal: '7%'
    },
    searchContainer: {
        flex: 1,
        justifyContent: 'flex-end',
        position: 'relative'
    },
    search: {
        paddingVertical: 7,
        paddingHorizontal: 10,
        paddingLeft: 35,
        backgroundColor: '#fff',
        borderRadius: 50
    },
    searchIcon: {
        position: 'absolute',
        top: '55%',
        left: 9
    },
    welcomeContainer: {
        flex: 2,
        justifyContent: 'center'
    },
    welcomeText: {
        fontSize: 25,
        fontWeight: 'bold'
    },
    welcomeInput: {
        padding: 10,
        backgroundColor: '#fff',
        marginVertical: 16
    },
    buttonInner: {
        width: '30%',
        borderRadius: 50,
        padding: 3,
        marginLeft: 'auto'
    },
    buttonText: {
        textAlign: 'center',
        color: "#fff",
        fontSize: 16
    },
    postsContainer: {
        flex: 8,
    },
    post: {
        marginBottom: 10
    },
    postText: {
        fontSize: 24,
        marginBottom: 5
    }
})