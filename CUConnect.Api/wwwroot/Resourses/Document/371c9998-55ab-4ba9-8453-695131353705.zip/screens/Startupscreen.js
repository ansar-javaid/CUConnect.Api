import { View, Text, Image, StyleSheet } from 'react-native'
import React, { useEffect } from 'react'
import comsatslogo from '../assets/comsatslogo.png'
import Loader from 'react-native-three-dots-loader'
import { LinearGradient } from 'expo-linear-gradient'

export default function Startupscreen({navigation}) {
  useEffect(()=> {
    setTimeout(() => {
      navigation.navigate('Signup')
    }, 5000);
  }, [navigation])
  return (
      <LinearGradient
        start={{ x: 0, y: 1 }} end={{ x: 0, y: 0 }}
        colors={['#105DA5', '#4B277E']}
        style={styles.container}>
        <Text style={styles.cuconnect}>CU CONNECT</Text>
        <Image source={comsatslogo} style={styles.logo} />
        {/* <Loader /> */}
      </LinearGradient>

  )
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#105DA5',
    alignItems: 'center',
    justifyContent: 'center'
  },
  logo: {
    width: 200,
    height: 200,
    marginBottom: '90%'
  },
  cuconnect: {
    color: '#fff',
    fontSize: 40,
    paddingBottom: 35,
  }
})