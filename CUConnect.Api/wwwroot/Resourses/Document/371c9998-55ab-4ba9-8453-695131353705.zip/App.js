import { StatusBar } from 'expo-status-bar';
import { SafeAreaView, StyleSheet, Text, View } from 'react-native';
import Signup from './screens/Signup';
import Login from './screens/Login';
import Homescreen from './screens/Homescreen';
import Startupscreen from './screens/Startupscreen';
import Cr from './screens/Cr';
import Department from './screens/Department';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';
import Post from './components/Post';
import { FontAwesome } from '@expo/vector-icons';

export default function App() {
  const Tab = createBottomTabNavigator();
  return (
   <SafeAreaView style={styles.container}>
     <NavigationContainer>
     <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: () => {
          let iconName;
          let style = {
            color: '7072E0'
          }
          let currentStyle = {}

          if (route.name === 'Signup') {
            iconName = 'arrow-left'
            currentStyle = {}
          } else if (route.name === 'Login') {
            iconName = 'plus'
            currentStyle =  style
          } else if (route.name === 'Home') {
            iconName = 'eye'
            currentStyle = {}
          }else if (route.name === 'Cr') {
            iconName = 'eye'
            currentStyle = {}
          }else if (route.name === 'Department') {
            iconName = 'eye'
            currentStyle = {}
          }

          // You can return any component that you like here!
          return <FontAwesome name={iconName} size={16} style={currentStyle}/>
        },
        tabBarActiveTintColor: 'gray',
        tabBarInactiveTintColor: 'gray',
      })}
      >
      <Tab.Screen options = {{headerShown: false, title:'Startup', tabBarStyle:{display:'none'}}} name="Splash" component={Startupscreen} />
      <Tab.Screen options = {{headerShown: false, title:'Logout'}} name="Signup" component={Signup} />
      <Tab.Screen options = {{headerShown: false, title:'New Post'}} name="Login" component={Login} />
      <Tab.Screen options = {{headerShown: false, title: 'Public View'}} name="Home" component={Homescreen} />
      <Tab.Screen options = {{headerShown: false, title: 'Cr'}} name="Cr" component={Cr} />
      <Tab.Screen options = {{headerShown: false, title: 'Department'}} name="Department" component={Department} />
    </Tab.Navigator>
    </NavigationContainer>
   </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  icon: {
    color: '#7072E0'
  }
});
